# 🦅 Claw Kit — Autonomous AI Development System

**Claw Kit** is an autonomous AI agent framework powered by GitHub Copilot CLI and Claude Sonnet 4.5 that enables self-directed software development with minimal human intervention.

---

## 🌟 Key Features

### 🤖 Autonomous Agent with Optional Specialists

Claw Kit uses a trust-first approach where a powerful base agent handles most work, calling specialists only when needed:

- **Base Agent** (Claude Sonnet 4.5) — Your autonomous developer that can handle 90% of tasks
- **Architect Agent** — Optional: Creates implementation plans for complex multi-module projects
- **Tester Agent** — Optional: Generates comprehensive test suites when needed
- **Debugger Agent** — Optional: Systematic debugging when stuck
- **Reviewer Agent** — Optional: Second opinion before major commits

### 🧠 Intelligent Model Selection

The agent uses the optimal model based on task complexity:

- **Claude Sonnet 4.5** (default) — Complex algorithms, distributed systems, security-critical code, new systems
- **GPT-5 mini** (fallback) — Simple parallelizable tasks only

### 📊 Minimal State Management

The system uses only essential state files:

- **DIRECTIVE.md** — What to build (set by you)
- **AGENT_RULE.md** — Self-improving knowledge base (learns from bugs)
- **REPO_STATE.md** — Auto-generated repository snapshot
- **PROGRESS.md** — Optional: For complex multi-day projects only

### 🔄 Self-Directed Development

The agent can write its own next directives, creating an infinite improvement loop:

    DIRECTIVE.md:
    Build a chat app. once done,
    clear the directive except this line and every line below this
    once you make the entire thing, create a new directive yourself that adds features, improvements, bug fixes to the program.

Result: Agent builds the app, then autonomously decides what feature to add next, then builds that, then decides the next feature, indefinitely.

### ⚡ Fleet Mode for Parallelization

Enable fleet mode to spawn multiple agents for independent tasks:

    /fleet
    "Create database models in models/db.py"
    "Write unit tests for authentication"
    "Generate API documentation"

Monitor with /tasks command.

### 🛡️ Core Quality Rules

Three non-negotiable requirements:

1. **Code must run** — Tests must pass before committing
2. **Learn from bugs** — Update AGENT_RULE.md when fixing issues
3. **Validate before commit** — Run tests, commit if pass

---

## 🏗️ Architecture

### File Structure

    clawkit/
    ├── AGENTS.md                    # Main agent protocol
    ├── DIRECTIVE.md                 # What to build
    ├── REPO_STATE.md               # Auto-generated state
    ├── AGENT_RULE.md              # Self-improving knowledge base
    ├── PROGRESS.md                # Optional task tracking
    ├── clawhip_lite.py            # State monitor
    └── .copilot/agents/           # Specialist agents
        ├── architect.md
        ├── reviewer.md
        ├── debugger.md
        ├── tester.md
        └── security.md

### How It Works

1. You set a directive in DIRECTIVE.md
2. Agent reads directive + AGENT_RULE.md (learns from past bugs)
3. Agent builds the feature autonomously
4. Agent runs tests, commits if they pass
5. Agent can optionally call specialist agents when needed
6. Agent updates AGENT_RULE.md with new learnings

---

## 🚀 Getting Started

### Prerequisites

1. **GitHub Copilot CLI** installed and authenticated
   
       npm install -g @githubnext/github-copilot-cli
       github-copilot-cli auth

2. **Python 3.10+** for state monitor
   
   Check version:
   
       # Linux/Mac:
       python3 --version
       
       # Windows:
       python --version

3. **Git** repository initialized
   
       git --version

### Installation

1. **Extract Claw Kit files** to your project directory

2. **Initialize git** (if not already done)
   
       git init
       git add .
       git commit -m "Initial setup"

3. **Start state monitor** (in separate terminal)
   
   Linux/Mac:
   
       python3 clawhip_lite.py
   
   Windows:
   
       python clawhip_lite.py
   
   One-time update alternative:
   
       python3 clawhip_lite.py --once   # Linux/Mac
       python clawhip_lite.py --once    # Windows

4. **Set your directive** in DIRECTIVE.md:
   
       # DIRECTIVE
       
       Build a REST API with JWT authentication and PostgreSQL backend

5. **Launch the agent**
   
       copilot --autopilot --yolo --max-autopilot-continues 300 --prompt "Read DIRECTIVE.md and AGENT_RULE.md, then execute the directive. Code must run. Tests must pass. Learn from bugs."

---

## 📖 Usage Examples

### Example 1: Simple Feature

DIRECTIVE.md:

    Add password reset with email verification

Command:

    copilot --autopilot --yolo --max-autopilot-continues 100 --prompt "Execute directive. Tests must pass. Update AGENT_RULE.md if you fix bugs."

### Example 2: Complex Project

DIRECTIVE.md:

    Build a real-time collaborative code editor with WebSocket support and operational transformation

Command:

    copilot --autopilot --yolo --max-autopilot-continues 300 --prompt "Read DIRECTIVE.md and AGENT_RULE.md. For complex multi-module work, use /agent architect first. Tests must pass. Update AGENT_RULE.md with learnings."

### Example 3: Self-Directed Infinite Loop

DIRECTIVE.md:

    Build a todo list app. once done,
    clear the directive except this line and every line below this
    once you make the entire thing, create a new directive yourself that adds features, improvements, bug fixes to the program.
    
    RULES:
    - One feature per iteration
    - Max 200 lines per iteration
    - Fix bugs before features
    - After 10 iterations, create HUMAN_REVIEW_NEEDED.md and stop

Agent will:
- Build todo app
- Clear directive top part
- Write new directive: "Add user authentication"
- Build that
- Write new directive: "Add real-time sync"
- Build that
- Continue indefinitely (or until iteration limit)

### Example 4: Production Hardening

DIRECTIVE.md:

    Stress test the authentication system and make it production ready

Agent will:
- Add comprehensive error handling
- Add input validation
- Add rate limiting
- Add security checks
- Add extensive tests
- Add logging

---

## 🎛️ Advanced Configuration

### State Monitor Options

Run once:

    python3 clawhip_lite.py --once   # Linux/Mac
    python clawhip_lite.py --once    # Windows

Change polling interval (default 90s):

    python3 clawhip_lite.py --interval 60   # Linux/Mac
    python clawhip_lite.py --interval 60    # Windows

Background mode (Linux/Mac):

    nohup python3 clawhip_lite.py &

Background mode (Windows - PowerShell):

    Start-Process python -ArgumentList "clawhip_lite.py" -WindowStyle Hidden

Recommended: Open separate terminal window on all platforms.

### Agent Invocation

Optional specialist agents (use when needed):

    /agent architect   # Planning for complex projects
    /agent reviewer    # Second opinion before big commit
    /agent debugger    # Stuck on tricky bug
    /agent tester      # Need comprehensive tests

Fleet mode:

    /fleet
    "Task 1"
    "Task 2"
    "Task 3"
    
    /tasks   # Monitor progress

Model switching (if needed):

    /model claude-sonnet-4.5   # Default
    /model gpt-5-mini          # For simple tasks only

---

## 📋 Workflow Cheat Sheet

### Starting New Project

1. Extract Claw Kit files
2. Initialize git
3. Start python3 clawhip_lite.py in separate terminal
4. Write directive in DIRECTIVE.md
5. Launch agent
6. Monitor AGENT_RULE.md to see what it learns

### Validation (Automatic)

Agent automatically:
1. Runs tests
2. Commits if tests pass
3. Fixes if tests fail
4. Updates AGENT_RULE.md when fixing bugs

### Troubleshooting

Agent stuck?
1. Check DIRECTIVE.md — Is task clear?
2. Check AGENT_RULE.md — Known issues?
3. Try /agent debugger
4. Check if tests are actually running

---

## 🔧 Core Files

### AGENTS.md
Main protocol file. Defines:
- Agent identity
- Core rules (code must run, learn from bugs)
- Optional specialist agents
- When to use each tool

Do not modify unless changing behavior.

### DIRECTIVE.md
What to build.

Simple format:

    Build X with Y features

Self-directed format:

    Build X. once done,
    clear the directive except this line and every line below this
    once you make the entire thing, create a new directive yourself that adds features, improvements, bug fixes to the program.

### AGENT_RULE.md
Self-improving knowledge base.

Template:

    # AGENT_RULE — Project Knowledge
    
    ## Bugs Fixed
    
    ### Bug: JWT token expiry
    Symptom: 401 errors after 1 hour
    Cause: Missing refresh logic
    Fix: Added refresh endpoint
    Prevention: Test token expiry
    
    ## Patterns That Work
    - Dependency injection for testability
    - Discriminated unions for state machines
    
    ## Standards
    - All public functions need docstrings
    - Type hints required
    - No hardcoded secrets

Agent reads this at startup and updates when fixing bugs.

### REPO_STATE.md
Auto-generated by clawhip_lite.py. Contains:
- Current branch
- Active directive
- Recent commits
- Uncommitted changes

Never edit manually.

### PROGRESS.md
Optional. Create only for complex multi-day work.

Template:

    # PROGRESS
    
    ## Status
    Building authentication module
    
    ## Done
    - User registration
    - Login endpoint
    
    ## Next
    - Password reset
    - Email verification
    
    ## Blockers
    - None

For simple tasks, skip this entirely.

---

## 🏆 Best Practices

### 1. Trust the Agent

Claude Sonnet 4.5 is powerful. Let it cook. Don't micromanage.

### 2. Clear Directives

Good:

    Build REST API with JWT auth, rate limiting, and PostgreSQL

Bad:

    Make it better

### 3. Read AGENT_RULE.md

Periodically check what the agent has learned:

    cat AGENT_RULE.md

### 4. Vibe First, Harden Later

Build fast:

    Build a chat app

Then harden:

    Stress test the chat app and make it production ready

### 5. Use Self-Directed Mode

For side projects, let agent decide next features:

    Build X. once done,
    clear the directive except this line and every line below this
    once you make the entire thing, create a new directive yourself

---

## 🐛 Known Limitations

1. **Local only** — Doesn't push to remote (safety feature)
2. **Rate limits** — >7 parallel fleet agents may hit limits
3. **Large projects** — >100k lines may need chunking
4. **System packages** — Can't install OS-level dependencies
5. **UI/UX** — Better at logic than design decisions

---

## 🔐 Security

Agent automatically:
- Never commits secrets
- Validates user input
- Uses parameterized SQL queries
- Implements rate limiting
- Checks for XSS, injection, path traversal

Call /agent security for thorough audits.

---

## 📊 Performance Expectations

- **Simple (1-5 files):** 10-20 minutes
- **Medium (10-20 files):** 30-60 minutes
- **Complex (40-60 files):** 3-6 hours

With fleet parallelization, medium projects can complete in 20-30 minutes.

---

## 🎓 Complete Example Session

1. Set directive:

Linux/Mac:

    echo "Build a URL shortener with analytics" > DIRECTIVE.md

Windows:

    echo Build a URL shortener with analytics > DIRECTIVE.md

2. Start monitor:

Linux/Mac:

    python3 clawhip_lite.py

Windows:

    python clawhip_lite.py

3. Launch agent:

    copilot --autopilot --yolo --max-autopilot-continues 200 --prompt "Read DIRECTIVE.md and AGENT_RULE.md. Execute directive. Tests must pass. Learn from bugs."

4. Check results:

    cat AGENT_RULE.md   # What did it learn?
    git log -1          # What did it build?
    pytest -v           # Do tests pass?

---

## 🚀 Quick Start (Copy-Paste)

Linux/Mac:

    # Terminal 1
    python3 clawhip_lite.py
    
    # Terminal 2
    copilot --autopilot --yolo --max-autopilot-continues 300 --prompt "Read DIRECTIVE.md and AGENT_RULE.md. Execute directive. Tests must pass. Learn from bugs."

Windows:

    # Terminal 1
    python clawhip_lite.py
    
    # Terminal 2
    copilot --autopilot --yolo --max-autopilot-continues 300 --prompt "Read DIRECTIVE.md and AGENT_RULE.md. Execute directive. Tests must pass. Learn from bugs."

---

## 📞 Support

Check in order:
1. AGENT_RULE.md — Known issues and solutions
2. DIRECTIVE.md — Is task clear?
3. REPO_STATE.md — Current state
4. Run /agent debugger — Systematic help

---

## Prompt Templates
Simple Feature
## 🎯 Philosophy

    Three rules:
    1. Code must run (tests pass)
    2. Learn from bugs (AGENT_RULE.md)
    3. Trust the agent (it's Sonnet 4.5)
    
    Everything else is optional.

**Built with ❤️ using Claude Sonnet 4.5 and GitHub Copilot CLI**

---

**Happy autonomous coding! 🦅**
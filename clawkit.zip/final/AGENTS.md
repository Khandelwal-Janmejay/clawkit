# AGENTS.md — Claw Workflow Protocol

## Identity

You are an autonomous coding agent. Implement work efficiently and ship working code.

---

## Startup

1. Read DIRECTIVE.md — what to do
2. Read AGENT_RULE.md — mandatory (learn from past bugs, follow standards)
3. Run git status — understand current state
4. Start working

---

## Core Rules

### 1. Code Must Run
- All code must execute without errors
- Tests must pass before committing
- If tests fail, fix them before moving on

### 2. Learn From Mistakes
- Always read AGENT_RULE.md at session start
- Update AGENT_RULE.md when you:
  - Fix a bug (document root cause + solution)
  - Discover a useful pattern
  - Make a mistake worth remembering

### 3. Validate Before Commit
Run tests (pytest, npm test, cargo test, etc.)
If pass → commit
If fail → fix first

---

## Available Agents (Use When Helpful)

You have access to specialized agents. Use them when you need them, not for everything.

| Agent | Command | Use When |
|-------|---------|----------|
| Architect | /agent architect | Complex multi-module planning |
| Reviewer | /agent reviewer | Want a second opinion before big commit |
| Debugger | /agent debugger | Stuck on a tricky bug |
| Tester | /agent tester | Need comprehensive test coverage |
| Fleet | /fleet | Parallelize simple independent tasks |

You decide when to call them. Don't call architect for a one-file change. Don't call reviewer for a typo fix.

---

## Optional: Progress Tracking

Create PROGRESS.md if you think it's useful — for example:
- Directive involves multiple steps over time
- You want to track what's done vs pending
- Complex project with many moving parts

For simple directives, skip it and just work.

---

## Model Selection

| Use GPT-5 mini for | Use Claude Sonnet for |
|--------------------|----------------------|
| Tests, docs, boilerplate | New systems from scratch |
| Simple bug fixes | Complex algorithms |
| Adding to existing code | Security-critical code |
| UI components | Architecture decisions |

Default to GPT-5 mini. Escalate if needed.

/model gpt-5-mini
/model claude-sonnet-4.5

---

## Autonomous Mode (No Directive)

When DIRECTIVE.md is empty:

1. Fix failing tests
2. Improve test coverage (aim for 80%+)
3. Resolve TODO/FIXME comments
4. Clean up linter warnings
5. Improve documentation

Commit each improvement separately.

---

## Don'ts

- Do not commit with failing tests
- Do not push to remote (local development only)
- Do not ignore AGENT_RULE.md — it exists for a reason

---

## AGENT_RULE.md Template

If it doesn't exist, create it:

# AGENT_RULE — Project Knowledge Base

## Coding Standards
- (Add as they emerge)

## Bugs & Solutions

### Bug: [Name]
Symptom: What you see
Cause: Why it happens
Fix: How to solve
Prevention: How to avoid

## Patterns That Work
- (Add good patterns here)

## Anti-Patterns
- (Add mistakes to avoid)

---

## Example Workflows

### Simple Task
Read DIRECTIVE.md → "Add a logout button"
Read AGENT_RULE.md → No relevant bugs
Implement → Write code
Test → pytest passes
Commit → Done

### Complex Task
Read DIRECTIVE.md → "Build authentication system"
Read AGENT_RULE.md → Note JWT bug from last time
Think: "This is multi-module, I'll plan first"
/agent architect → Get PLAN.md
Implement modules
/agent tester → Get good coverage
Test → All pass
Commit → Done
Update AGENT_RULE.md → Add auth patterns learned

### Debugging Session
Tests failing → Read error
Check AGENT_RULE.md → Not a known bug
Try fix → Still failing
/agent debugger → Get systematic help
Fixed → Update AGENT_RULE.md with new bug entry
Commit

---

## Stress Testing / Production Readiness

When you want production-quality code:

1. Build it first (vibe code)
2. Then ask: "Stress test this system"
3. Or: "Make this production ready"
4. Or: "Security audit this code"

The agent will:
- Add error handling
- Add rate limiting
- Add input validation
- Add logging
- Add comprehensive tests
- Check for edge cases


# AGENT_RULE — Project Knowledge Base

## Project: Neon Ruins (Roguelike Game)

### Architecture Overview
- **Tech Stack:** React + TypeScript + Vite + PixiJS + Zustand + Supabase
- **Architecture:** Entity Component System (ECS) with layered modules
- **See:** PLAN.md for detailed module breakdown and implementation order

### Implementation Phases
**Current Phase:** Phase 1 - MVP Prototype (Weeks 1-2)
**Current Status:** Core engine complete, working on gameplay systems
**Completed:**
- ✅ M20: Utilities (Vector2, Random, SpatialGrid)
- ✅ M1: Game Loop (60 FPS fixed timestep, entity pooling)
- ✅ M2: Input System (WASD, mouse, sprint)
- ✅ M3: Physics & Collision (AABB, spatial grid)
- ✅ M4: Render System (PixiJS integration, sprites, camera follow)
- ✅ M14: Canvas Integration (React + PixiJS)
- ✅ M5: Player (movement, sprint, abilities integrated)
- ✅ M6: Combat (pistol, SMG, shotgun all implemented with proper mechanics)
- ✅ M8: Enemy AI - ALL types (Rusher, Shooter, Tank, Sniper, Spawner)
- ✅ M18: Particle System (burst, trail, ring, stream effects)
- ✅ M21: Abilities (Dash, EMP, Shield - all functional with particles)
- ✅ TestLevel integration (walls, spawn points)
- ✅ All TypeScript lint warnings fixed
- ✅ PLAN.md created with phased implementation approach
- ✅ Unit tests created and passing (36/36 tests)

**In Progress:**
- P1.1: Manual playtest verification

**Next Steps (per PLAN.md):** 
1. ✅ Complete enemy roster (DONE - all 5 types implemented)
2. ✅ PLAN.md created (DONE)
3. ✅ Create test infrastructure (DONE - vitest setup, 36 passing tests)
4. Manual playtest all systems
5. HUD improvements (weapon info, minimap)
6. Game states & menus (main menu, pause, death screen)
7. Inventory system (10x10 Tetris-style grid)
8. Procedural level generation (BSP algorithm)

### Model Selection Rules
- **Use Claude Sonnet for:**
  - Game loop architecture (M1)
  - Physics & collision systems (M3)
  - PixiJS integration & rendering (M4)
  - Player mechanics & abilities (M5)
  - Weapon & combat system (M6)
  - Inventory grid logic (M7)
  - Enemy AI & pathfinding (M8)
  - Procedural level generation (M9)
  - Particle systems & effects (M18)

- **Use GPT-5 mini or /fleet for:**
  - Utilities & helpers (M20)
  - Input system (M2)
  - Data configuration (M19)
  - Upgrade system (M10)
  - Class system (M11)
  - Menu UI components (M13)
  - Canvas integration (M14)
  - Supabase integration (M15)
  - Database schema (M16)
  - Audio system (M17)

### Coding Standards
- Use TypeScript strict mode
- Follow ECS pattern: entities have components, systems process them
- Keep game logic separate from React components
- Use path aliases (@engine, @game, @components, @store, @services, @types, @utils)
- All game data in JSON files under src/data/

## Bugs & Solutions

### Bug: Build errors in ParticleSystem and EMP
**Symptom:** TypeScript compilation failed with errors about SpriteComponent missing width/height and unused imports
**Cause:** SpriteComponent interface didn't have width/height properties, unused Player import in EMP.ts
**Fix:** 
  - Added `width?: number; height?: number;` to SpriteComponent interface
  - Removed unused import from EMP.ts
**Prevention:** Always check interface definitions before using new properties
**Status:** FIXED - Build now completes successfully

### Bug: TestLevel not integrated
**Symptom:** Game had no walls, player could move off-screen
**Cause:** TestLevel.ts existed but was never instantiated in App.tsx
**Fix:** Import and instantiate TestLevel in startGame(), use spawn positions for player and enemies
**Prevention:** Always check that all created modules are actually used

### Bug: TypeScript 'any' type warnings
**Symptom:** 6 ESLint warnings about using 'any' type
**Cause:** Generic component system and ability context using 'any'
**Fix:** Replaced with proper types:
  - `Map<string, unknown>` for component storage
  - `Record<string, unknown>` for ability context
  - Type guards for component lifecycle methods
**Prevention:** Use `unknown` instead of `any` as default, then narrow with type guards

### Bug: Vector2/Random/SpatialGrid test failures
**Symptom:** 19/36 tests failing - methods not found or returning wrong types
**Cause:** Implementation didn't match test expectations:
  - Vector2 returned new instances instead of mutating
  - Random method names didn't match (randInt vs int, randFloat vs range)
  - SpatialGrid used string IDs instead of entity objects
**Fix:**
  - Vector2: Changed to mutate in place, added length() and lengthSquared()
  - Random: Added method aliases (range, int, boolean) 
  - SpatialGrid: Refactored to support entity objects with query/update/remove
  - SpatialGrid: Fixed query to check actual bounds, not just cells
**Prevention:** Write implementations first OR ensure tests match actual API design
**Status:** FIXED - All 36 tests passing

## Patterns That Work

### PixiJS + React Integration
- Create PixiJS Application in React useEffect
- Cleanup on unmount to prevent memory leaks
- Use refs to access canvas element
- Keep PixiJS state separate from React state

### Entity Component System
- Entities are just containers with ID + position
- Components are data (HealthComponent, SpriteComponent)
- Systems process entities with specific components
- Use entity pooling for frequently created/destroyed objects (projectiles, particles)

### Procedural Generation
- Always use seeded RNG for reproducible levels
- Store seed with run data for daily challenges
- BSP (Binary Space Partitioning) for room layout
- A* for pathfinding

## Anti-Patterns
- ❌ Don't mix game logic with React components
- ❌ Don't use React state for high-frequency updates (use game engine state)
- ❌ Don't create new objects every frame (use object pooling)
- ❌ Don't call expensive operations in render loop (cache results)

## Game-Specific Notes

### Performance Targets
- 60 FPS on desktop, 30 FPS on mobile
- Max 100 active entities at once
- Use spatial partitioning for collision detection
- Sprite batching for rendering

### Game Balance
- See game_description.md for detailed balance specs
- DPS targets by floor, enemy TTK (time-to-kill)
- Credit and fragment economy carefully balanced

### Testing Strategy
- Manual playtesting after each major system
- Test each floor difficulty (1, 5, 10, 15, 20)
- Test all classes and weapons
- Performance profiling with browser DevTools

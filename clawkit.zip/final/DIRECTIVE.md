# DIRECTIVE
Build the game described in game_description.md.

INITIALIZATION:
- Read game_description.md in full (it contains all specs, mechanics, systems)
- Use /agent architect to create implementation plan breaking down into modules
- Refer back to game_description.md whenever you need clarification

IMPLEMENTATION RULES:
- One major system per iteration (e.g., movement system, combat system, networking)
- Complex systems (networking, physics, rendering) use Claude Sonnet
- Simple systems (UI, configs, utilities) can use GPT-5 mini or /fleet
- Tests must pass before committing
- Update AGENT_RULE.md with game-specific bugs and patterns

QUALITY STANDARDS:
- All game systems must be playable and tested
- No placeholder/stub implementations
- Performance targets from game_description.md must be met
- Multiplayer sync must be tested if specified

SELF-DIRECTIVE PRIORITIES (after initial build):
1. Fix bugs and crashes
2. Optimize performance bottlenecks
3. Add features from game_description.md "nice to have" section
4. Improve game balance based on testing
5. Add polish (animations, effects, sound integration points)

CHECKPOINTS:
- After core game loop is playable, create PLAYTEST_READY.md
- After 15 iterations, create HUMAN_REVIEW_NEEDED.md
- Document all deviations from game_description.md in CHANGES.md

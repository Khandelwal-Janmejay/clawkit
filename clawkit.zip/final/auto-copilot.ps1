# auto-copilot.ps1
# Runs copilot autopilot, detects rate limits, waits exact time, restarts.

param(
    [int]$MaxContinues = 300,
    [string]$Prompt = "Read DIRECTIVE.md and AGENT_RULE.md, then execute the directive. Tests must pass before committing. Update AGENT_RULE.md when you fix bugs.",
    [string]$LogFile = "copilot-auto.log",
    [int]$MaxIterations = 50,
    [int]$MaxRuntimeHours = 8
)

function Remove-Ansi {
    param([string]$Text)
    return [regex]::Replace($Text, '\x1b\[[0-9;]*[mGKHFJABCDsuhl]', '')
}

function Get-WaitSeconds {
    param([string]$Text)
    $clean = Remove-Ansi $Text
    if ($clean -match "try again in (\d+)\s*hour")   { return [int]$Matches[1] * 3600 }
    if ($clean -match "try again in (\d+)\s*minute") { return [int]$Matches[1] * 60   }
    if ($clean -match "try again in (\d+)\s*second") { return [int]$Matches[1]        }
    if ($clean -match "wait (\d+)\s*hour")            { return [int]$Matches[1] * 3600 }
    if ($clean -match "wait (\d+)\s*minute")          { return [int]$Matches[1] * 60   }
    return 3600
}

function Test-RateLimit {
    param([string]$Text)
    $clean = Remove-Ansi $Text
    return ($clean -match "rate_limit|rate limit|burst limit|too many requests|quota exceeded|try again in|try again later|429")
}

function Start-Countdown {
    param([int]$Seconds)
    $end = (Get-Date).AddSeconds($Seconds)
    while ((Get-Date) -lt $end) {
        $rem = [math]::Ceiling(($end - (Get-Date)).TotalSeconds)
        if ($rem -le 0) { break }
        $h = [math]::Floor($rem / 3600)
        $m = [math]::Floor(($rem % 3600) / 60)
        $s = $rem % 60
        Write-Host "`r  Resuming in $($h.ToString('00'))h $($m.ToString('00'))m $($s.ToString('00'))s  " -NoNewline -ForegroundColor Yellow
        Start-Sleep -Seconds 1
    }
    Write-Host "`r  Wait complete - restarting agent...              " -ForegroundColor Green
}

function Write-Log {
    param([string]$Msg, [string]$Color = "White")
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - $Msg"
    Write-Host $line -ForegroundColor $Color
    $line | Out-File $LogFile -Append -Encoding utf8
}

function Test-ShouldStop {
    if (Test-Path "STOP_AGENT") {
        Write-Log "STOP_AGENT file detected. Stopping." "Red"
        Remove-Item "STOP_AGENT" -ErrorAction SilentlyContinue
        return $true
    }
    if (Test-Path "HUMAN_REVIEW_NEEDED.md") {
        Write-Log "Human review requested. Stopping." "Yellow"
        return $true
    }
    if (Test-Path "DIRECTIVE.md") {
        $d = (Get-Content "DIRECTIVE.md" -Raw -ErrorAction SilentlyContinue)
        $trimmed = if ($d) { $d.Trim() } else { "" }
        if ($trimmed -eq "" -or $trimmed -eq "# DIRECTIVE") {
            Write-Log "DIRECTIVE.md empty - work complete." "Green"
            return $true
        }
    }
    return $false
}

# --- MAIN ---
$startTime  = Get-Date
$iteration  = 0
$sessionLog = "copilot-session.log"

Write-Log "Auto-Copilot starting. Max $MaxIterations iterations / $MaxRuntimeHours h" "Green"
Write-Log "Session log: $sessionLog  |  Master log: $LogFile" "Cyan"

while ($iteration -lt $MaxIterations) {

    if (((Get-Date) - $startTime).TotalHours -ge $MaxRuntimeHours) {
        Write-Log "Max runtime reached." "Yellow"
        break
    }

    if (Test-ShouldStop) { break }

    $iteration++
    Write-Log "=== Iteration $iteration ===" "Cyan"

    "" | Out-File $sessionLog -Encoding utf8

    Write-Log "Launching copilot --autopilot --yolo --max-autopilot-continues $MaxContinues" "Gray"

    & copilot --autopilot --yolo --max-autopilot-continues $MaxContinues `
              --prompt $Prompt 2>&1 | Tee-Object -FilePath $sessionLog

    $output = Get-Content $sessionLog -Raw -ErrorAction SilentlyContinue
    if (-not $output) { $output = "" }

    "=== Iteration $iteration ===" | Out-File $LogFile -Append -Encoding utf8
    $output          | Out-File $LogFile -Append -Encoding utf8

    if (Test-RateLimit $output) {
        $wait = Get-WaitSeconds $output
        $h = [math]::Floor($wait / 3600)
        $m = [math]::Floor(($wait % 3600) / 60)
        Write-Log "Rate limit hit. Waiting $h h $m m then restarting..." "Yellow"

        ($output -split "`n") |
            Where-Object { (Remove-Ansi $_) -match "rate|limit|Error" } |
            Select-Object -First 1 |
            ForEach-Object { Write-Log "  $($_.Trim())" "DarkYellow" }

        Start-Countdown -Seconds $wait
        continue
    }

    Write-Log "Copilot session ended normally." "Gray"

    if (Test-ShouldStop) { break }

    Write-Log "Pausing 10s before next iteration..." "Gray"
    Start-Sleep -Seconds 10
}

$elapsed = (Get-Date) - $startTime
Write-Log "=== Done. Iterations: $iteration | Runtime: $("{0:hh\:mm\:ss}" -f $elapsed) ===" "Green"